package search;

import utilities.StringUtilities;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.*;

/**
 * This class accepts the path to a file
 * and stores word statistics for the file.
 *
 * Note: This file should implement IFileSearcher.
 *
 * @author Patrick Luong
 * @version 1.0
 */
public class FileSearch implements IFileSearcher {
    
    private int wordCount = 0;
    private int lineCount = 0;
    private int wordFrequeciesCounter = 0;
    private String word;
    private List<String> wordList = new ArrayList<>();
    private List<String> lineList = new ArrayList<>();
    private Map<String, Integer> wordFrequecies = new TreeMap<>();
    /**
     * This method is the file constructor that accepts the user
     * text file choice, the lines are either sent directly into a list as lines
     * or the lines are split into word elements and stored in another list
     * @param filePath accepts the user's choice for the text file
     */
    public FileSearch(String filePath) {
        Scanner reader = null;
        try {
            reader = new Scanner(new FileInputStream(filePath));
            while (reader.hasNextLine()) {

                String line = reader.nextLine();
                lineList.add(line);
                String[] words = StringUtilities.cleanString(line).toLowerCase().split("\\s+");

                for (String word : words) {
                    if (!word.equals("")) {
                        analyizeFile(word);
                    }
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error reading from file " + e.getMessage());
        } finally {
            if (reader != null) {
                reader.close();
            }
        }
    }

    /**
     * this method checks if the user's word is in the text file
     * @param word user's input
     * @return true if the word is found in the text, else false
     */
    @Override
    public boolean containsWord(String word) {
        boolean wordContains = false;
        for (String words : wordList) {
            if (words.equals(word)) {
                wordContains = true;
            }
        }
        return wordContains;
    }

    /**
     * this method counts the number of user's word in the text file
     * @param word user's input 
     * @return how many times word occurs in the text file
     */
    @Override
    public int wordCount(String word) {
        this.word = word;
        for (String words : wordList) {
            if (words.equals(word)) {
                wordCount++;
            }
        }
        return wordCount;
    }

    /**
     * this method searches through text list of lines for the user's word
     * while counting each line iteration, if the word is found the line containing
     * the word along with the current line count is added into the return list
     * @param word accepts the user's word
     * @return a list of lines where the word occurs
     * with the respective line number
     */
    @Override
    public List<String> wordSearch(String word) {
        List<String> wordSearch = new ArrayList<>();
        for (String line : lineList) {
            lineCount++;
            if (line.contains(word)) {
                wordSearch.add(lineCount + " " + line);
            }
        }
        return wordSearch;
    }

    /**
     * this method loops through the list of all words, constructing keys
     * for each new word encountered
     * along a word frequency counter as its value, if the word already exist
     * the counter is then updated
     * @return a map of unique words as a key
     * and the number of occurences in the file text as a value
     */
    @Override
    public Map<String, Integer> wordFrequecies() {
        for (String words : wordList) {
            if (!wordFrequecies.containsKey(words)) {
                wordFrequecies.put(words, wordFrequeciesCounter);
            } else {
                wordFrequecies.put(words, wordFrequecies.get(words) + 1);
            }
        }
        return wordFrequecies;
    }

    /**
     * this method first loops through the word list
     * the words are the key value, for every new word, another iteration
     * through the line list is applied and all lines containing the word
     * is added into a new list
     * after the list iteration the map constructs a new set with the word and a list with
     * the appropriate lines
     * @return a map of of words and each line where they occur
     */
    @Override
    public Map<String, List<String>> wordSearches() {
        Map<String, List<String>> wordSearchs = new TreeMap<>();
        List<String> lines = new ArrayList<>();
        for (String words : wordList) {
            if (!wordSearchs.containsKey(words)) {
                for (String line : lineList) {
                    if (line.contains(words)) {
                        lines.add(line); //add all lines first and then
                    }
                }
                wordSearchs.put(words, lines);
            }
        }
        return wordSearchs;
    }

    /**
     * constructs a set of unique words found in a text
     * @return a TreeSet of unique words
     */
    @Override
    public Set<String> words() {
        Set<String> wordSet = new TreeSet<>();
        for (String words : wordList) {
            wordSet.add(words);
        }
        return wordSet;
    }

    /**
     * returns the size of the TreeSet of unique words
     * @return number of unique words from the text file
     */
    @Override
    public int uniqueWordsCount() {
        return words().size();
    }

    /**
     * returns the number of words (size of the word list) in a text file
     * @return number of words from the text file
     */
    @Override
    public int allWordsCount() {
        return wordList.size();
    }

    /**
     * this methood constructs the word list
     * @param word accepts a cleaned string of appropriately split words 
     * from the text file
     */
    private void analyizeFile(String word) {
        wordList.add(word);
        wordFrequecies.put(word, wordFrequeciesCounter);
    }

    /**
     * retrieves word from user
     * @return word
     */
    public String getWord(){
        return word;
    }

    /**
     *  it is always a good idea to implement a toString
     *  This toString returns the given size
     *  of our two most used list in this program
     * @return the size of the two main list used in this program
     */
    @Override
    public String toString(){
        return "word list size " + wordList.size() + "\n" +
        "line list size " + lineList.size() + "\n";
    }

}
