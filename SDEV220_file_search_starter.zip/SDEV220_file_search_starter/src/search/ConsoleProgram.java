package search;

import consoleio.Console;
import java.io.File;
import java.util.*;

/**
 * This file contains a console program that
 * reads in text files from the /files directory
 * and lets the user analyze their contents using
 * the FileSearch class.
 *
 * @author Patrick Luong
 * @version 1.0
 */
public class ConsoleProgram {

    private static FileSearch fileSearch;
    private static int choiceTextMenu;
    private static int choiceUserCount = 0;
    private static int userOptionInteractiveMenu;
    private static boolean enterExit = true;
    private static Map<Integer, String> menuList = new TreeMap<>();
    private static File[] files = new File("files").listFiles();

    /**
     * the main method that calls the file menu, it consist of
     * a welcome message, chooise file, and a goodbye
     * essentially the broad procedure of the code
     * The entry point of the application.
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args){

        System.out.println("Welcome to my File Search Program\n" +
                            "*************************************\n"+
                            "This program lets you open text files\n" +
                            "from the /files directory and to\n" +
                            "analysze their contents\n" +
                            "**************************************");

            System.out.println("Choose a File ");
            fileMenu();
            System.out.println("Goodbye");
    }

    /**
     * this method displays the file options
     * the recieves the user's option and then
     * calls the interactive menu
     */
    private static void fileMenu(){
        if(enterExit) {
            do {
                int countTextMenu = 0;

                for (int i = 0; i < files.length; i++) {
                    System.out.print(countTextMenu + " ");
                    System.out.println(files[i]);
                    countTextMenu++;
                }
                choiceTextMenu = Console.readInt("Choose a file ");
            }while(choiceTextMenu < 0 || choiceTextMenu > files.length - 1);

            for (int i = 0; i < files.length; i++) {
                if (choiceTextMenu == choiceUserCount) {
                    System.out.println();
                    interactiveMenu(files[i]);
                }
                choiceUserCount++;
            }
        }
    }

    /**
     * this is the interactive menu where the user can choose from a list to display
     * different types of data about the text
     * @param accepts user's file choice
     *and displays options for information available to display
     */
    private static void interactiveMenu(File files){
        System.out.print("Choose an option");
        String fileString = files.toString();
        fileSearch = new FileSearch(fileString);

        do {
            menuList.put(0, "Word count");
            menuList.put(1, "Unique word count");
            menuList.put(2, "Print words");
            menuList.put(3, "Word frequency");
            menuList.put(4, "Word search");
            menuList.put(5, "Change file");
            menuList.put(6, "Exit");

            System.out.println();
            for (Map.Entry<Integer, String> entry : menuList.entrySet()) {
                System.out.println(entry.getKey() + " " + entry.getValue());
            }
            userOptionInteractiveMenu = Console.readInt("Choose an option ");
        }while(userOptionInteractiveMenu < 0 || userOptionInteractiveMenu > menuList.size() - 1);
        setUserOptionInteractiveMenu();
    }

    /**
     *a method to compare user's option menuList key value and outputs the method
     */
    private static void setUserOptionInteractiveMenu(){

        if (menuList.get(userOptionInteractiveMenu).equals(menuList.get(0))) {
            wordCount();
        } else if (menuList.get(userOptionInteractiveMenu).equals(menuList.get(1))) {
            uniqueWordCount();
        } else if (menuList.get(userOptionInteractiveMenu).equals(menuList.get(2))) {
            printWords();
        } else if (menuList.get(userOptionInteractiveMenu).equals(menuList.get(3))) {
            wordFrequency();
        } else if (menuList.get(userOptionInteractiveMenu).equals(menuList.get(4))) {
            wordSearch();
        } else if (menuList.get(userOptionInteractiveMenu).equals(menuList.get(5))) {
            fileMenu();
        } else if (menuList.get(userOptionInteractiveMenu).equals(menuList.get(6))) {
            enterExit = false;
        }
        if(enterExit) {
            interactiveMenu(files[choiceTextMenu]);
        }
            fileMenu();
    }

    /**
     * method to receive the number of words in a text file
     */
    private static void wordCount(){
        int wordCount = fileSearch.allWordsCount();
        System.out.println("\n" + "Words found: " + wordCount + "\n");
        }

    /**
    * method to receive the number of unique words in a text file
    */
    private static void uniqueWordCount(){
        int uniqueWords = fileSearch.uniqueWordsCount();
        System.out.println("\n" + "Unique words found: " + uniqueWords + "\n");
    }

    /**
     * method to print all unique words found in a text file
     */
    private static void printWords(){
        Set<String> wordSet = new TreeSet<>(fileSearch.words());
        System.out.println("\n" + "Words +" +
                "*************************************");
        for(String words : wordSet){
            System.out.println(words);
        }
        System.out.println();
    }

    /**
     * method to print unique words and
     * how many times they occur in the text file
     */
    private static void wordFrequency(){
        System.out.println("\n" + "Word frequencies\n" +
                "*************************************");
        for(Map.Entry<String, Integer> entry :
        fileSearch.wordFrequecies().entrySet()){
        System.out.println(entry.getKey() + " " + entry.getValue());
        }
        System.out.println();
    }

    /**
     * searches the user's word and display every line from the the text file
     * containing that word
     */
    private static void wordSearch(){
        String word = Console.readLine("Enter word ");
        if(fileSearch.containsWord(word)){
            System.out.println("\n" + "Lines found\n" +
                    "*************************************");
            for (String wordList: fileSearch.wordSearch(word)) {
                System.out.println(wordList);
            }
            System.out.println("*************************************");
        }
        else{
            System.out.println(word + " is not found in text\n");
        }
    }

}





